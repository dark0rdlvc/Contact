using System.Security.Claims;
using ContactBook.Models;
using ContactBook.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContactBook.Controllers
{
    [Authorize]
    public class GroupsController : Controller
    {
        private readonly IGroupService _groups;
        private readonly IContactService _contacts;

        public GroupsController(IGroupService groups, IContactService contacts)
        {
            _groups = groups;
            _contacts = contacts;
        }

        private string UserId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

        public IActionResult Index()
        {
            var groups = _groups.GetAll(UserId);
            var contacts = _contacts.GetAll(UserId);
            ViewBag.ContactCounts = groups.ToDictionary(g => g.Id, g => contacts.Count(c => c.GroupId == g.Id));
            return View(groups);
        }

        public IActionResult Create() => View(new Group());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Group group)
        {
            if (!ModelState.IsValid) return View(group);
            group.Id = Guid.NewGuid().ToString();
            group.OwnerId = UserId;
            group.CreatedAt = DateTime.UtcNow;
            _groups.Add(group);
            TempData["Success"] = $"Grupa '{group.Name}' kreirana.";
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(string id)
        {
            var group = _groups.GetById(id);
            if (group == null || group.OwnerId != UserId) return NotFound();
            return View(group);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Group group)
        {
            if (!ModelState.IsValid) return View(group);
            var existing = _groups.GetById(group.Id);
            if (existing == null || existing.OwnerId != UserId) return NotFound();
            group.OwnerId = UserId;
            group.CreatedAt = existing.CreatedAt;
            _groups.Update(group);
            TempData["Success"] = $"Grupa '{group.Name}' izmenjena.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string id)
        {
            var group = _groups.GetById(id);
            if (group == null || group.OwnerId != UserId) return NotFound();
            _groups.Delete(id);
            TempData["Success"] = $"Grupa '{group.Name}' obrisana.";
            return RedirectToAction(nameof(Index));
        }
    }
}
