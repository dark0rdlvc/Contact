using System.Security.Claims;
using ContactBook.Models;
using ContactBook.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContactBook.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly IContactService _contacts;
        private readonly IGroupService _groups;

        public HomeController(IContactService contacts, IGroupService groups)
        {
            _contacts = contacts;
            _groups = groups;
        }

        public IActionResult Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier)!;
            var contacts = _contacts.GetAll(userId);
            var groups = _groups.GetAll(userId);

            var groupStats = groups.Select(g => new GroupStat
            {
                GroupName = g.Name,
                Color = g.Color,
                Count = contacts.Count(c => c.GroupId == g.Id)
            }).ToList();

            groupStats.Add(new GroupStat
            {
                GroupName = "Bez grupe",
                Color = "#94a3b8",
                Count = contacts.Count(c => string.IsNullOrEmpty(c.GroupId))
            });

            var vm = new DashboardViewModel
            {
                TotalContacts = contacts.Count,
                TotalGroups = groups.Count,
                GroupStats = groupStats,
                RecentContacts = contacts.OrderByDescending(c => c.CreatedAt).Take(5).ToList()
            };

            return View(vm);
        }

        [AllowAnonymous]
        public IActionResult Landing() => View();
    }
}
