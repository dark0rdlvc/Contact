using System.Security.Claims;
using System.Text.Json;
using System.Xml.Linq;
using ContactBook.Models;
using ContactBook.Services;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Kernel.Colors;
using iText.Kernel.Font;
using iText.IO.Font.Constants;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContactBook.Controllers
{
    [Authorize]
    public class ContactsController : Controller
    {
        private readonly IContactService _contacts;
        private readonly IGroupService _groups;

        public ContactsController(IContactService contacts, IGroupService groups)
        {
            _contacts = contacts;
            _groups = groups;
        }

        private string UserId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

        // GET: Contacts
        public IActionResult Index(string? search, string? groupId, string sortBy = "name", string sortDir = "asc", int page = 1)
        {
            var allContacts = _contacts.Search(UserId, search, groupId, sortBy, sortDir);
            const int pageSize = 9;
            var total = allContacts.Count;
            var paged = allContacts.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            var vm = new ContactListViewModel
            {
                Contacts = paged,
                Groups = _groups.GetAll(UserId),
                SearchTerm = search,
                GroupFilter = groupId,
                SortBy = sortBy,
                SortDir = sortDir,
                Page = page,
                PageSize = pageSize,
                TotalCount = total
            };

            return View(vm);
        }

        // GET: Contacts/Details/5
        public IActionResult Details(string id)
        {
            var contact = _contacts.GetById(id);
            if (contact == null || contact.OwnerId != UserId) return NotFound();
            ViewBag.Group = contact.GroupId != null ? _groups.GetById(contact.GroupId) : null;
            return View(contact);
        }

        // GET: Contacts/Create
        public IActionResult Create()
        {
            ViewBag.Groups = _groups.GetAll(UserId);
            return View(new Contact());
        }

        // POST: Contacts/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Contact contact)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Groups = _groups.GetAll(UserId);
                return View(contact);
            }
            contact.Id = Guid.NewGuid().ToString();
            contact.OwnerId = UserId;
            contact.CreatedAt = DateTime.UtcNow;
            _contacts.Add(contact);
            TempData["Success"] = $"Kontakt {contact.FullName} dodat.";
            return RedirectToAction(nameof(Index));
        }

        // GET: Contacts/Edit/5
        public IActionResult Edit(string id)
        {
            var contact = _contacts.GetById(id);
            if (contact == null || contact.OwnerId != UserId) return NotFound();
            ViewBag.Groups = _groups.GetAll(UserId);
            return View(contact);
        }

        // POST: Contacts/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Contact contact)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Groups = _groups.GetAll(UserId);
                return View(contact);
            }
            var existing = _contacts.GetById(contact.Id);
            if (existing == null || existing.OwnerId != UserId) return NotFound();
            contact.OwnerId = UserId;
            contact.CreatedAt = existing.CreatedAt;
            _contacts.Update(contact);
            TempData["Success"] = $"Kontakt {contact.FullName} izmenjen.";
            return RedirectToAction(nameof(Index));
        }

        // POST: Contacts/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string id)
        {
            var contact = _contacts.GetById(id);
            if (contact == null || contact.OwnerId != UserId) return NotFound();
            _contacts.Delete(id);
            TempData["Success"] = $"Kontakt {contact.FullName} obrisan.";
            return RedirectToAction(nameof(Index));
        }

        // GET: Contacts/Export?format=xml|json|pdf
        public IActionResult Export(string format = "xml")
        {
            var contacts = _contacts.GetAll(UserId);
            var groups = _groups.GetAll(UserId);

            if (format == "json")
            {
                var json = JsonSerializer.Serialize(contacts, new JsonSerializerOptions { WriteIndented = true });
                return File(System.Text.Encoding.UTF8.GetBytes(json), "application/json", "contacts.json");
            }

            if (format == "pdf")
            {
                using var ms = new MemoryStream();
                var writer = new PdfWriter(ms);
                var pdf = new PdfDocument(writer);
                var doc = new Document(pdf, iText.Kernel.Geom.PageSize.A4);
                doc.SetMargins(36, 36, 36, 36);

                // Title
                var boldFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
                var regularFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);

                var title = new Paragraph("ContactBook — Spisak kontakata")
                    .SetFont(boldFont)
                    .SetFontSize(18)
                    .SetFontColor(new DeviceRgb(99, 102, 241))
                    .SetMarginBottom(4);
                doc.Add(title);

                var subtitle = new Paragraph($"Generisano: {DateTime.Now:dd.MM.yyyy HH:mm} | Ukupno: {contacts.Count} kontakata")
                    .SetFont(regularFont)
                    .SetFontSize(9)
                    .SetFontColor(new DeviceRgb(120, 120, 140))
                    .SetMarginBottom(16);
                doc.Add(subtitle);

                // Table
                var table = new Table(UnitValue.CreatePercentArray(new float[] { 2.5f, 2.5f, 3f, 2f, 2.5f, 2f }));
                table.SetWidth(UnitValue.CreatePercentValue(100));

                var headerBg = new DeviceRgb(40, 42, 65);
                var headerColor = new DeviceRgb(160, 165, 210);
                string[] headers = { "Ime", "Prezime", "Email", "Telefon", "Kompanija", "Grupa" };

                foreach (var h in headers)
                {
                    var cell = new Cell()
                        .Add(new Paragraph(h).SetFont(boldFont).SetFontSize(9).SetFontColor(headerColor))
                        .SetBackgroundColor(headerBg)
                        .SetPadding(6);
                    table.AddHeaderCell(cell);
                }

                var rowLight = new DeviceRgb(28, 30, 46);
                var rowDark = new DeviceRgb(32, 34, 52);
                var textColor = new DeviceRgb(220, 222, 240);
                var textMuted = new DeviceRgb(120, 130, 170);

                for (int i = 0; i < contacts.Count; i++)
                {
                    var c = contacts[i];
                    var grp = groups.FirstOrDefault(g => g.Id == c.GroupId);
                    var bg = i % 2 == 0 ? rowLight : rowDark;

                    string[] values = {
                        c.FirstName,
                        c.LastName,
                        c.Email,
                        c.Phone ?? "—",
                        c.Company ?? "—",
                        grp?.Name ?? "Bez grupe"
                    };

                    foreach (var v in values)
                    {
                        var cell = new Cell()
                            .Add(new Paragraph(v).SetFont(regularFont).SetFontSize(8).SetFontColor(textColor))
                            .SetBackgroundColor(bg)
                            .SetPadding(5);
                        table.AddCell(cell);
                    }
                }

                doc.Add(table);

                var footer = new Paragraph($"\nContactBook — Web Programiranje projekat")
                    .SetFont(regularFont)
                    .SetFontSize(8)
                    .SetFontColor(textMuted)
                    .SetTextAlignment(TextAlignment.CENTER)
                    .SetMarginTop(16);
                doc.Add(footer);

                doc.Close();
                return File(ms.ToArray(), "application/pdf", "contacts.pdf");
            }

            // Default: XML
            var xmlDoc = new XDocument(new XElement("Contacts",
                contacts.Select(c => new XElement("Contact",
                    new XAttribute("id", c.Id),
                    new XElement("FirstName", c.FirstName),
                    new XElement("LastName", c.LastName),
                    new XElement("Email", c.Email),
                    new XElement("Phone", c.Phone ?? ""),
                    new XElement("Company", c.Company ?? ""),
                    new XElement("GroupId", c.GroupId ?? ""),
                    new XElement("CreatedAt", c.CreatedAt.ToString("O"))
                ))));

            return File(System.Text.Encoding.UTF8.GetBytes(xmlDoc.ToString()), "application/xml", "contacts.xml");
        }
    }
}
