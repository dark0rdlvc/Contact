using System.Security.Claims;
using ContactBook.Models;
using ContactBook.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ContactBook.Controllers
{
    [Authorize]
    public class ProfileController : Controller
    {
        private readonly IUserService _users;
        private readonly IContactService _contacts;
        private readonly IGroupService _groups;

        public ProfileController(IUserService users, IContactService contacts, IGroupService groups)
        {
            _users = users;
            _contacts = contacts;
            _groups = groups;
        }

        private string UserId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

        public IActionResult Index()
        {
            var user = _users.GetById(UserId);
            if (user == null) return NotFound();
            ViewBag.ContactCount = _contacts.Count(UserId);
            ViewBag.GroupCount = _groups.GetAll(UserId).Count;
            return View(user);
        }

        public IActionResult Edit()
        {
            var user = _users.GetById(UserId);
            if (user == null) return NotFound();
            var vm = new ProfileEditViewModel
            {
                Username = user.Username,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                AvatarUrl = user.AvatarUrl,
                Bio = user.Bio
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(ProfileEditViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);
            var user = _users.GetById(UserId);
            if (user == null) return NotFound();
            user.Username = vm.Username;
            user.Email = vm.Email;
            user.FirstName = vm.FirstName;
            user.LastName = vm.LastName;
            user.AvatarUrl = vm.AvatarUrl;
            user.Bio = vm.Bio;
            _users.Update(user);
            TempData["Success"] = "Profil ažuriran.";
            return RedirectToAction(nameof(Index));
        }
    }
}
