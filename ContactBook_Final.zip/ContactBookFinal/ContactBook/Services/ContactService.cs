using System.Xml.Linq;
using ContactBook.Models;

namespace ContactBook.Services
{
    public interface IContactService
    {
        List<Contact> GetAll(string ownerId);
        Contact? GetById(string id);
        void Add(Contact contact);
        void Update(Contact contact);
        void Delete(string id);
        List<Contact> Search(string ownerId, string? term, string? groupId, string sortBy, string sortDir);
        int Count(string ownerId);
    }

    public class ContactService : IContactService
    {
        private readonly string _xmlPath;
        private readonly object _lock = new();

        public ContactService(IWebHostEnvironment env)
        {
            _xmlPath = Path.Combine(env.ContentRootPath, "App_Data", "contacts.xml");
            EnsureFile();
        }

        private void EnsureFile()
        {
            if (!File.Exists(_xmlPath))
                new XDocument(new XElement("Contacts")).Save(_xmlPath);
        }

        private List<Contact> ReadAll()
        {
            lock (_lock)
            {
                var doc = XDocument.Load(_xmlPath);
                return doc.Root!.Elements("Contact").Select(e => new Contact
                {
                    Id = e.Attribute("id")?.Value ?? Guid.NewGuid().ToString(),
                    FirstName = e.Element("FirstName")?.Value ?? "",
                    LastName = e.Element("LastName")?.Value ?? "",
                    Email = e.Element("Email")?.Value ?? "",
                    Phone = e.Element("Phone")?.Value,
                    Address = e.Element("Address")?.Value,
                    Company = e.Element("Company")?.Value,
                    Note = e.Element("Note")?.Value,
                    AvatarUrl = e.Element("AvatarUrl")?.Value,
                    GroupId = e.Element("GroupId")?.Value,
                    OwnerId = e.Element("OwnerId")?.Value ?? "",
                    CreatedAt = DateTime.TryParse(e.Element("CreatedAt")?.Value, out var dt) ? dt : DateTime.UtcNow
                }).ToList();
            }
        }

        private void SaveAll(List<Contact> contacts)
        {
            lock (_lock)
            {
                var doc = new XDocument(new XElement("Contacts",
                    contacts.Select(c => new XElement("Contact",
                        new XAttribute("id", c.Id),
                        new XElement("FirstName", c.FirstName),
                        new XElement("LastName", c.LastName),
                        new XElement("Email", c.Email),
                        new XElement("Phone", c.Phone ?? ""),
                        new XElement("Address", c.Address ?? ""),
                        new XElement("Company", c.Company ?? ""),
                        new XElement("Note", c.Note ?? ""),
                        new XElement("AvatarUrl", c.AvatarUrl ?? ""),
                        new XElement("GroupId", c.GroupId ?? ""),
                        new XElement("OwnerId", c.OwnerId),
                        new XElement("CreatedAt", c.CreatedAt.ToString("O"))
                    ))));
                doc.Save(_xmlPath);
            }
        }

        public List<Contact> GetAll(string ownerId) =>
            ReadAll().Where(c => c.OwnerId == ownerId).ToList();

        public Contact? GetById(string id) =>
            ReadAll().FirstOrDefault(c => c.Id == id);

        public void Add(Contact contact)
        {
            var all = ReadAll();
            all.Add(contact);
            SaveAll(all);
        }

        public void Update(Contact contact)
        {
            var all = ReadAll();
            var idx = all.FindIndex(c => c.Id == contact.Id);
            if (idx >= 0) all[idx] = contact;
            SaveAll(all);
        }

        public void Delete(string id)
        {
            var all = ReadAll();
            all.RemoveAll(c => c.Id == id);
            SaveAll(all);
        }

        public List<Contact> Search(string ownerId, string? term, string? groupId, string sortBy, string sortDir)
        {
            var contacts = GetAll(ownerId);

            if (!string.IsNullOrWhiteSpace(term))
            {
                var t = term.ToLower();
                contacts = contacts.Where(c =>
                    c.FullName.ToLower().Contains(t) ||
                    c.Email.ToLower().Contains(t) ||
                    (c.Company ?? "").ToLower().Contains(t) ||
                    (c.Phone ?? "").Contains(t)
                ).ToList();
            }

            if (!string.IsNullOrWhiteSpace(groupId))
                contacts = contacts.Where(c => c.GroupId == groupId).ToList();

            contacts = (sortBy, sortDir) switch
            {
                ("name", "asc") => contacts.OrderBy(c => c.LastName).ThenBy(c => c.FirstName).ToList(),
                ("name", "desc") => contacts.OrderByDescending(c => c.LastName).ThenByDescending(c => c.FirstName).ToList(),
                ("email", "asc") => contacts.OrderBy(c => c.Email).ToList(),
                ("email", "desc") => contacts.OrderByDescending(c => c.Email).ToList(),
                ("company", "asc") => contacts.OrderBy(c => c.Company).ToList(),
                ("company", "desc") => contacts.OrderByDescending(c => c.Company).ToList(),
                ("date", "asc") => contacts.OrderBy(c => c.CreatedAt).ToList(),
                ("date", "desc") => contacts.OrderByDescending(c => c.CreatedAt).ToList(),
                _ => contacts.OrderBy(c => c.LastName).ToList()
            };

            return contacts;
        }

        public int Count(string ownerId) => GetAll(ownerId).Count;
    }
}
