using System.Xml.Linq;
using ContactBook.Models;

namespace ContactBook.Services
{
    public interface IGroupService
    {
        List<Group> GetAll(string ownerId);
        Group? GetById(string id);
        void Add(Group group);
        void Update(Group group);
        void Delete(string id);
    }

    public class GroupService : IGroupService
    {
        private readonly string _xmlPath;
        private readonly object _lock = new();

        public GroupService(IWebHostEnvironment env)
        {
            _xmlPath = Path.Combine(env.ContentRootPath, "App_Data", "groups.xml");
            EnsureFile();
        }

        private void EnsureFile()
        {
            if (!File.Exists(_xmlPath))
                new XDocument(new XElement("Groups")).Save(_xmlPath);
        }

        private List<Group> ReadAll()
        {
            lock (_lock)
            {
                var doc = XDocument.Load(_xmlPath);
                return doc.Root!.Elements("Group").Select(e => new Group
                {
                    Id = e.Attribute("id")?.Value ?? Guid.NewGuid().ToString(),
                    Name = e.Element("Name")?.Value ?? "",
                    Description = e.Element("Description")?.Value,
                    Color = e.Element("Color")?.Value ?? "#4f46e5",
                    Icon = e.Element("Icon")?.Value ?? "people",
                    OwnerId = e.Element("OwnerId")?.Value ?? "",
                    CreatedAt = DateTime.TryParse(e.Element("CreatedAt")?.Value, out var dt) ? dt : DateTime.UtcNow
                }).ToList();
            }
        }

        private void SaveAll(List<Group> groups)
        {
            lock (_lock)
            {
                var doc = new XDocument(new XElement("Groups",
                    groups.Select(g => new XElement("Group",
                        new XAttribute("id", g.Id),
                        new XElement("Name", g.Name),
                        new XElement("Description", g.Description ?? ""),
                        new XElement("Color", g.Color),
                        new XElement("Icon", g.Icon),
                        new XElement("OwnerId", g.OwnerId),
                        new XElement("CreatedAt", g.CreatedAt.ToString("O"))
                    ))));
                doc.Save(_xmlPath);
            }
        }

        public List<Group> GetAll(string ownerId) =>
            ReadAll().Where(g => g.OwnerId == ownerId).ToList();

        public Group? GetById(string id) =>
            ReadAll().FirstOrDefault(g => g.Id == id);

        public void Add(Group group)
        {
            var all = ReadAll();
            all.Add(group);
            SaveAll(all);
        }

        public void Update(Group group)
        {
            var all = ReadAll();
            var idx = all.FindIndex(g => g.Id == group.Id);
            if (idx >= 0) all[idx] = group;
            SaveAll(all);
        }

        public void Delete(string id)
        {
            var all = ReadAll();
            all.RemoveAll(g => g.Id == id);
            SaveAll(all);
        }
    }
}
