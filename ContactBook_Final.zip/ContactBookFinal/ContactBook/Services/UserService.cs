using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;
using ContactBook.Models;

namespace ContactBook.Services
{
    public interface IUserService
    {
        AppUser? GetById(string id);
        AppUser? GetByUsername(string username);
        bool Register(AppUser user, string password);
        AppUser? Login(string username, string password);
        void Update(AppUser user);
    }

    public class UserService : IUserService
    {
        private readonly string _xmlPath;
        private readonly object _lock = new();

        public UserService(IWebHostEnvironment env)
        {
            _xmlPath = Path.Combine(env.ContentRootPath, "App_Data", "users.xml");
            EnsureFile();
        }

        private void EnsureFile()
        {
            if (!File.Exists(_xmlPath))
                new XDocument(new XElement("Users")).Save(_xmlPath);
        }

        private static string HashPassword(string password)
        {
            using var sha = SHA256.Create();
            return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(password + "CB_SALT_2024")));
        }

        private List<AppUser> ReadAll()
        {
            lock (_lock)
            {
                var doc = XDocument.Load(_xmlPath);
                return doc.Root!.Elements("User").Select(e => new AppUser
                {
                    Id = e.Attribute("id")?.Value ?? Guid.NewGuid().ToString(),
                    Username = e.Element("Username")?.Value ?? "",
                    Email = e.Element("Email")?.Value ?? "",
                    PasswordHash = e.Element("PasswordHash")?.Value ?? "",
                    FirstName = e.Element("FirstName")?.Value,
                    LastName = e.Element("LastName")?.Value,
                    AvatarUrl = e.Element("AvatarUrl")?.Value,
                    Bio = e.Element("Bio")?.Value,
                    RegisteredAt = DateTime.TryParse(e.Element("RegisteredAt")?.Value, out var dt) ? dt : DateTime.UtcNow
                }).ToList();
            }
        }

        private void SaveAll(List<AppUser> users)
        {
            lock (_lock)
            {
                var doc = new XDocument(new XElement("Users",
                    users.Select(u => new XElement("User",
                        new XAttribute("id", u.Id),
                        new XElement("Username", u.Username),
                        new XElement("Email", u.Email),
                        new XElement("PasswordHash", u.PasswordHash),
                        new XElement("FirstName", u.FirstName ?? ""),
                        new XElement("LastName", u.LastName ?? ""),
                        new XElement("AvatarUrl", u.AvatarUrl ?? ""),
                        new XElement("Bio", u.Bio ?? ""),
                        new XElement("RegisteredAt", u.RegisteredAt.ToString("O"))
                    ))));
                doc.Save(_xmlPath);
            }
        }

        public AppUser? GetById(string id) => ReadAll().FirstOrDefault(u => u.Id == id);

        public AppUser? GetByUsername(string username) =>
            ReadAll().FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));

        public bool Register(AppUser user, string password)
        {
            var all = ReadAll();
            if (all.Any(u => u.Username.Equals(user.Username, StringComparison.OrdinalIgnoreCase)))
                return false;
            if (all.Any(u => u.Email.Equals(user.Email, StringComparison.OrdinalIgnoreCase)))
                return false;
            user.PasswordHash = HashPassword(password);
            all.Add(user);
            SaveAll(all);
            return true;
        }

        public AppUser? Login(string username, string password)
        {
            var hash = HashPassword(password);
            return ReadAll().FirstOrDefault(u =>
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
                u.PasswordHash == hash);
        }

        public void Update(AppUser user)
        {
            var all = ReadAll();
            var idx = all.FindIndex(u => u.Id == user.Id);
            if (idx >= 0) all[idx] = user;
            SaveAll(all);
        }
    }
}
