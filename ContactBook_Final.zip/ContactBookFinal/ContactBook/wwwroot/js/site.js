// Auto-dismiss toast
document.addEventListener('DOMContentLoaded', function () {
    const toast = document.getElementById('cbToast');
    if (toast) {
        setTimeout(() => { toast.style.display = 'none'; }, 4000);
    }

    // Animate chart bars
    document.querySelectorAll('.cb-chart-bar[data-width]').forEach(bar => {
        bar.style.width = '0%';
        requestAnimationFrame(() => {
            setTimeout(() => {
                bar.style.width = bar.getAttribute('data-width') + '%';
            }, 100);
        });
    });

    // Active nav link
    const currentPath = window.location.pathname.toLowerCase();
    document.querySelectorAll('.cb-nav-link').forEach(link => {
        const href = link.getAttribute('href')?.toLowerCase();
        if (href && currentPath.startsWith(href) && href !== '/') {
            link.classList.add('active');
        } else if (href === '/' && currentPath === '/') {
            link.classList.add('active');
        }
    });
});
