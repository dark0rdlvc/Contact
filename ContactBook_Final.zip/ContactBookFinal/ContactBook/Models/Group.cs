using System.ComponentModel.DataAnnotations;

namespace ContactBook.Models
{
    public class Group
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required(ErrorMessage = "Naziv grupe je obavezan.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Naziv mora biti između 2 i 50 karaktera.")]
        [Display(Name = "Naziv grupe")]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Opis")]
        [StringLength(200)]
        public string? Description { get; set; }

        [Display(Name = "Boja")]
        public string Color { get; set; } = "#4f46e5";

        [Display(Name = "Ikonica")]
        public string Icon { get; set; } = "people";

        [Display(Name = "Vlasnik")]
        public string OwnerId { get; set; } = string.Empty;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
