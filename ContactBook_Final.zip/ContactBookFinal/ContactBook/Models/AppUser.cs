using System.ComponentModel.DataAnnotations;

namespace ContactBook.Models
{
    public class AppUser
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required(ErrorMessage = "Korisničko ime je obavezno.")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Korisničko ime mora biti između 3 i 30 karaktera.")]
        [Display(Name = "Korisničko ime")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email je obavezan.")]
        [EmailAddress(ErrorMessage = "Unesite ispravan email.")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        [Display(Name = "Ime")]
        [StringLength(50)]
        public string? FirstName { get; set; }

        [Display(Name = "Prezime")]
        [StringLength(50)]
        public string? LastName { get; set; }

        [Display(Name = "Avatar URL")]
        public string? AvatarUrl { get; set; }

        [Display(Name = "Bio")]
        [StringLength(300)]
        public string? Bio { get; set; }

        public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;

        public string DisplayName => !string.IsNullOrEmpty(FirstName) ? $"{FirstName} {LastName}".Trim() : Username;
    }
}
