using System.ComponentModel.DataAnnotations;

namespace ContactBook.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Korisničko ime je obavezno.")]
        [Display(Name = "Korisničko ime")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Lozinka je obavezna.")]
        [DataType(DataType.Password)]
        [Display(Name = "Lozinka")]
        public string Password { get; set; } = string.Empty;

        public bool RememberMe { get; set; }
    }

    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Korisničko ime je obavezno.")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Mora biti između 3 i 30 karaktera.")]
        [Display(Name = "Korisničko ime")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email je obavezan.")]
        [EmailAddress(ErrorMessage = "Unesite ispravan email.")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Lozinka je obavezna.")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Lozinka mora imati najmanje 6 karaktera.")]
        [DataType(DataType.Password)]
        [Display(Name = "Lozinka")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Potvrda lozinke je obavezna.")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Lozinke se ne podudaraju.")]
        [Display(Name = "Potvrdi lozinku")]
        public string ConfirmPassword { get; set; } = string.Empty;

        [Display(Name = "Ime")]
        [StringLength(50)]
        public string? FirstName { get; set; }

        [Display(Name = "Prezime")]
        [StringLength(50)]
        public string? LastName { get; set; }
    }

    public class ProfileEditViewModel
    {
        [Required(ErrorMessage = "Korisničko ime je obavezno.")]
        [StringLength(30, MinimumLength = 3)]
        [Display(Name = "Korisničko ime")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email je obavezan.")]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Ime")]
        [StringLength(50)]
        public string? FirstName { get; set; }

        [Display(Name = "Prezime")]
        [StringLength(50)]
        public string? LastName { get; set; }

        [Display(Name = "Avatar URL")]
        public string? AvatarUrl { get; set; }

        [Display(Name = "Bio")]
        [StringLength(300)]
        public string? Bio { get; set; }
    }

    public class ContactListViewModel
    {
        public List<Contact> Contacts { get; set; } = new();
        public List<Group> Groups { get; set; } = new();
        public string? SearchTerm { get; set; }
        public string? GroupFilter { get; set; }
        public string SortBy { get; set; } = "name";
        public string SortDir { get; set; } = "asc";
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 9;
        public int TotalCount { get; set; }
        public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);
    }

    public class DashboardViewModel
    {
        public int TotalContacts { get; set; }
        public int TotalGroups { get; set; }
        public List<GroupStat> GroupStats { get; set; } = new();
        public List<Contact> RecentContacts { get; set; } = new();
    }

    public class GroupStat
    {
        public string GroupName { get; set; } = string.Empty;
        public string Color { get; set; } = "#4f46e5";
        public int Count { get; set; }
    }
}
