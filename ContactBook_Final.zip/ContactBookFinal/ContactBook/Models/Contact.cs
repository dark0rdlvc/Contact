using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;

namespace ContactBook.Models
{
    [XmlRoot("Contact")]
    public class Contact
    {
        [XmlAttribute("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required(ErrorMessage = "Ime je obavezno.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Ime mora biti između 2 i 50 karaktera.")]
        [Display(Name = "Ime")]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Prezime je obavezno.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Prezime mora biti između 2 i 50 karaktera.")]
        [Display(Name = "Prezime")]
        public string LastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email je obavezan.")]
        [EmailAddress(ErrorMessage = "Unesite ispravan email.")]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Phone(ErrorMessage = "Unesite ispravan broj telefona.")]
        [Display(Name = "Telefon")]
        public string? Phone { get; set; }

        [Display(Name = "Adresa")]
        [StringLength(200)]
        public string? Address { get; set; }

        [Display(Name = "Kompanija")]
        [StringLength(100)]
        public string? Company { get; set; }

        [Display(Name = "Beleška")]
        [StringLength(500)]
        public string? Note { get; set; }

        [Display(Name = "Slika profila (URL)")]
        public string? AvatarUrl { get; set; }

        [Display(Name = "Datum dodavanja")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Display(Name = "Vlasnik")]
        public string OwnerId { get; set; } = string.Empty;

        [Display(Name = "Grupa")]
        public string? GroupId { get; set; }

        public string FullName => $"{FirstName} {LastName}";

        public string Initials => $"{(FirstName.Length > 0 ? FirstName[0] : '?')}{(LastName.Length > 0 ? LastName[0] : '?')}";
    }
}
